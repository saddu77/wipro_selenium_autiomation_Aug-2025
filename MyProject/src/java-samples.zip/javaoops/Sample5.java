package javaoops;

public class Sample5 {
	int number = 20;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample5 obj = new Sample5();
		System.out.println(obj.number);
	}

}
