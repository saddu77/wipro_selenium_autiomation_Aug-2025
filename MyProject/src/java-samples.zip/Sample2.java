
public class Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Addition of two numbers
		int number1 = 20;
		int number2 = 30;
		int result;
		result = number1 + number2;
		System.out.println("sum of two numbers are: " + result);
		
//		Subtraction
//		Multiplication
//		Division
		
	}

}
