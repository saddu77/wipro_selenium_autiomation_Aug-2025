package javastrings;

public class Sample5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "hello";
		String s2 = "WELCOME";
		System.out.println(s1.toUpperCase());
		System.out.println(s2.toLowerCase());
		
	}
}
