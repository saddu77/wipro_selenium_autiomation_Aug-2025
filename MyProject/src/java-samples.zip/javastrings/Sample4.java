package javastrings;

public class Sample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "welcome";
		System.out.println(s1.indexOf('l'));
		
		System.out.println(s1.isEmpty());
		String s2 = "";
		System.out.println(s2.isEmpty());
		
		System.out.println(s1.charAt(3));
	}

}
