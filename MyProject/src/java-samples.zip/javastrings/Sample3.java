package javastrings;

public class Sample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = " welcome ";
		System.out.println(s1.length());
		System.out.println(s1.trim().length());
	}
}
