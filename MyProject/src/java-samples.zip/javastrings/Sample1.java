package javastrings;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] ch = {'h','e','l','l','o'};
		System.out.println(ch);
		String msg = "hello";
		System.out.println(msg);
	}
}
