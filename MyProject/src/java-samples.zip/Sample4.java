
public class Sample4 {
	
	// function with arguments or parameters
	static void addition(int x,int y){
		int result;
		result = x + y;
		System.out.println("sum of two numbers are: " + result);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// function call with arguments		
		addition(40, 30);
		addition(30, 20);
		addition(50, 20);
	}
}
