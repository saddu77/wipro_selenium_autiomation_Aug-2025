package javavariables;

import javaacessmodifers.*;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(Sample1.number1);
//		System.out.println(Sample1.number2);
		System.out.println(Sample1.number3);
	}
}
