
public class Sample3 {
// Sample Addition Function
	static void addition(){
		int number1 = 20;
		int number2 = 30;
		int result;
		result = number1 + number2;
		System.out.println("sum of two numbers are: " + result);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addition();
		addition();
		addition();
	}

}
