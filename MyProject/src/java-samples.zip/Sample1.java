
public class Sample1 {
	//variables
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//datatype varName = value;
		int number = 20;
		System.out.println("Value is: " + number);
		
		float salary = 55000;
		System.out.println("Salary is : " + salary);
		
		double pi = 3.14;
		System.out.println("Pi value is : " + pi);
		
		char ch = 'A';
		System.out.println("Char is : " + ch);
		
		Boolean flag = true;
		System.out.println("Flag is: " + flag);
	}
}
