package javaconditions;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 17;
		if( age >= 18) {
			System.out.println("Eligible to vote !!!");
		} else {
			System.out.println("Not Eligible to vote !!!");
		}
	}
}
