package javarrays;

public class Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] names;
		names = new String[5];
		names[0]= "Alex";
		names[1] = "Bob";
		names[2] = "Clare";
		names[3] = "Daniel";
		names[4] = "Emily";
		
		for(int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
	}

}
