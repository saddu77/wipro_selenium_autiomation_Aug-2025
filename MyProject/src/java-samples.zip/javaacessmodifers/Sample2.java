package javaacessmodifers;

public class Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(Sample1.number); //private variable
		System.out.println(Sample1.number1);
		System.out.println(Sample1.number2);
		System.out.println(Sample1.number3);
	}

}
